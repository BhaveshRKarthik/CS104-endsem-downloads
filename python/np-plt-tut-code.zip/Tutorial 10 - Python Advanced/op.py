import numpy as np

a = np.array([[1, 2], [3, 4]])
b = np.array([[5, 6], [1, 2]])
print("array a:", a)
print("array b:", b)
c = a + b
print("array c:", c)
d = a - b
print("array d:", d)
e = a * b
print("array e:", e)
f = a / b
print("array f:", f)
g = a ** b
print("array g:", g)
h = a % b
print("array h:", h)
i = a // b
print("array i:", i)
